﻿<?php
ini_set('display_errors', 1);
print_r(get_include_path());
require_once 'application/functions.php';
require_once 'application/bootstrap.php';
