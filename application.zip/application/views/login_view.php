<h1>Login page</h1>
<p>
	<form action="" method="post">
		<table class="login">
			<tr>
				<td><small class="form-text text-muted">Login</small><input type="text" name="login" class="form-control"></td>
			</tr>
			<tr>
				<td><small class="form-text text-muted">Password</small><input type="password" name="password" class="form-control"></td>
			</tr>
		</table>
		<br>
		<input type="submit" value="Войти" name="btn" class="btn btn-light">
	</form>
</p>