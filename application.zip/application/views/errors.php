<?php foreach ($data['errors'] as $error): ?>
	<span><?= $error; ?></span>
<?php endforeach ?>