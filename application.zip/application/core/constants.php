<?php
define('BASE_URL', 'http://mvctasklist.zzz.com.ua/');
define('BASE_DIR', __DIR__ . '/../../');