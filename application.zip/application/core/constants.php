<?php
define('BASE_URL', 'http://mvc.localhost/');
define('BASE_DIR', __DIR__ . '/../../');