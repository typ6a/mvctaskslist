<?php
require_once 'core/constants.php';
require_once 'core/model.php';
require_once 'core/view.php';
require_once 'core/controller.php';
require_once 'core/route.php';
require_once 'core/helpers.php';
require_once 'libs/claviska/Simpleimage.php';
session_start();
Route::start(); 
