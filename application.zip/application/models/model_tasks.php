<?php

class Model_Tasks extends Model
{
	
	public function get_data()
	{	
		
		return array(
			
			array(
				'Task' => 'make a csv app',
				'UserName' => 'Dmitry',
				'UserEmail' => 'd@example.com',
				'status' => 'do'
			),

			array(
				'Task' => 'drink cup of coffee',
				'UserName' => 'Вася',
				'UserEmail' => 'vas@example.com',
				'status' => 'do'
			),

			array(
				'Task' => 'drink cup of tea',
				'UserName' => 'Dmitry',
				'UserEmail' => 'd@example.com',
				'status' => 'do'
			),

			array(
				'Task' => 'learn english',
				'UserName' => 'vova',
				'UserEmail' => 'vovan@example.com',
				'status' => 'done'
			),

			array(
				'Task' => 'watch TV',
				'UserName' => 'Lena',
				'UserEmail' => 'l@example.com',
				'status' => 'do'
			),

			array(
				'Task' => 'go to the gym',
				'UserName' => 'Masha',
				'UserEmail' => 'maria@example.com',
				'status' => 'do'
			),

			array(
				'Task' => 'get the php jr dev job',
				'UserName' => 'max',
				'UserEmail' => 'max@example.com',
				'status' => 'done'
			),

			array(
				'Task' => 'make money',
				'UserName' => 'petr',
				'UserEmail' => 'petya@example.com',
				'status' => 'do'
			),

			
		);
	}

}
